www.kd1s.com



 
الاوامر 

pkg install php

pkg install git

pkg install unzip

pkg install mc

git clone https://github.com/xznsx/kd1s2

cd kd1s2

unzip kd1s2.zip

cd kd1s

php login.php

php run.php

